<!DOCTYPE HTML><html>
<head>
	<meta charset="utf-8" />
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="Tuesday 2014-10-16" />
	<title>xampp (phpStudy 重新编译版)</title>
</head>

<body>

<?php
print ("<input type=\"text\" name=\"pay\" value=\"123\"><br>");

?> 
</body>
</html>
