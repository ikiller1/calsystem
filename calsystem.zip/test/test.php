
<?php
/* include 'Common.php';

$conn=Login($ROLE_ROOT);
CreateTestData($conn); */
echo $_GET["id"];
?> 