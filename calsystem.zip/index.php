<?php
include 'header.php';
?>
<p>
<a href="test/EchoOrderId.php">echoorderid</a>
</p>
<p>
<a href="test/func.html">insert</a>
</p>
<p>
<a href="test/fun.php">快速创建环境</a>
</p>


<p>
<a href="test/print.php">打印某个月</a>
</p>

<p>
<a href="test/js.html">table adjust test </a>
</p>
<p>
<a href="test/test.php?id=981">test</a>
</p>
<p>
<a href="test/demo.php">BLANK</a>
</p>

<p>
<a href="test/showtablesAll.php">DEMO 1</a>
</p>
<p>
<a href="test/profit.php">计算月利润</a>
</p>
<p>
<a href="test/printday.html">计算某一天的利润</a>
</p>
<p>
<a href="test/remote.html">jquery test</a>
</p>
</body>
</html>
